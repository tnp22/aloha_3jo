package com.aloha.movie_project.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import groovy.util.logging.Slf4j;

@Controller
@Slf4j
@RequestMapping("/cast")
public class CastController {
    
}
