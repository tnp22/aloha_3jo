package com.aloha.movie_project.domain;

import lombok.Data;

@Data
public class UserAuth {
    private int no;
    private String userId;
    private String auth;
}
