package com.aloha.movie_project.domain;

import lombok.Data;

@Data
public class Theater {
    private int no;
    private String id;
    private String cinemaId;
    private String map;
}
