package com.aloha.movie_project.domain;

import lombok.Data;

@Data
public class AuthList {
    private int no;
    private String typeName;
    private String description;
}
