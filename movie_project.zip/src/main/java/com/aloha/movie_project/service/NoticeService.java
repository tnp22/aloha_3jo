package com.aloha.movie_project.service;

import java.util.List;

import com.aloha.movie_project.domain.Notice;

public interface NoticeService {
    public List<Notice> list();
}
